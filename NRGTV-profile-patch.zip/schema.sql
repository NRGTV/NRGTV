-- profiles table, 1:1 with auth.users
create table profiles (
  id uuid references auth.users(id) primary key,
  username text unique not null,
  display_name text,
  avatar_url text,
  bio text,
  banner_url text,
  is_verified boolean default false,
  verified_type text, -- e.g. 'staff', 'partner', 'creator', null
  created_at timestamptz default now()
);

-- lock down who can flip is_verified
alter table profiles enable row level security;

create policy "profiles are publicly readable"
  on profiles for select using (true);

create policy "users can update their own non-verification fields"
  on profiles for update using (auth.uid() = id);
